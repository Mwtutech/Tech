declare function isRegExp(value: any): boolean;
export default isRegExp;
