import decode from "./decode.js";
import encode from "./encode.js";

export { encode, decode };
