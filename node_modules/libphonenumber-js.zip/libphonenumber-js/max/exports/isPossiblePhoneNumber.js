import withMetadataArgument from './withMetadataArgument.js'
import { isPossiblePhoneNumber as _isPossiblePhoneNumber } from '../../core/index.js'

export function isPossiblePhoneNumber() {
	return withMetadataArgument(_isPossiblePhoneNumber, arguments)
}