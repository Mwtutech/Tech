var convert = require('./convert'),
    func = convert('assignInAll', require('../assignIn'));

func.placeholder = require('./placeholder');
module.exports = func;
