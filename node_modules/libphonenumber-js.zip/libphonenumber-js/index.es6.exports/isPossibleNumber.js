// Deprecated.

import withMetadataArgument from '../min/exports/withMetadataArgument.js'

import _isPossibleNumber from '../es6/legacy/isPossibleNumber.js'

export function isPossibleNumber() {
	return withMetadataArgument(_isPossibleNumber, arguments)
}
