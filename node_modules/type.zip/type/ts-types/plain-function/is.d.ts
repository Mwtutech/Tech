declare function isPlainFunction(value: any): boolean;
export default isPlainFunction;
