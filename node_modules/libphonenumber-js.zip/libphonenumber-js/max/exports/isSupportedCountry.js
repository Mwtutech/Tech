import withMetadataArgument from './withMetadataArgument.js'
import { isSupportedCountry as _isSupportedCountry } from '../../core/index.js'

export function isSupportedCountry() {
	return withMetadataArgument(_isSupportedCountry, arguments)
}