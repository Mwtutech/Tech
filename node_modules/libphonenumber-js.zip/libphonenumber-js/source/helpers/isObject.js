const objectConstructor = {}.constructor;

export default function isObject(object) {
  return object !== undefined && object !== null && object.constructor === objectConstructor;
}
