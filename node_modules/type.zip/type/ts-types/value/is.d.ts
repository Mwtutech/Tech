declare function isValue(value: any): boolean;
export default isValue;
