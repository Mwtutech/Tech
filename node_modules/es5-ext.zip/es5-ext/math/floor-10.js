"use strict";

module.exports = require("./_decimal-adjust")("floor");
