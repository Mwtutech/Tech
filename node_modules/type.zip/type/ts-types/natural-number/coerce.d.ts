declare function coerceToNaturalNumber(value: any): number | null;
export default coerceToNaturalNumber;
