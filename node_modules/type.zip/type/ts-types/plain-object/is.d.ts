declare function isPlainObject(value: any): boolean;
export default isPlainObject;
