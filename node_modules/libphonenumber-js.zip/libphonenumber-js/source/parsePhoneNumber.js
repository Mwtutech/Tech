import normalizeArguments from './normalizeArguments.js'
import parsePhoneNumber_ from './parsePhoneNumber_.js'

export default function parsePhoneNumber() {
	const { text, options, metadata } = normalizeArguments(arguments)
	return parsePhoneNumber_(text, options, metadata)
}
