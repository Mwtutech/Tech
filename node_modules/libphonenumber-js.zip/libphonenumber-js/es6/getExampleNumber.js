import PhoneNumber from './PhoneNumber.js';
export default function getExampleNumber(country, examples, metadata) {
  if (examples[country]) {
    return new PhoneNumber(country, examples[country], metadata);
  }
}
//# sourceMappingURL=getExampleNumber.js.map