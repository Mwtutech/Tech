import { PointContainer } from '../utils';

export interface ImageQuantizerYieldValue {
  progress: number;
  pointContainer?: PointContainer;
}
