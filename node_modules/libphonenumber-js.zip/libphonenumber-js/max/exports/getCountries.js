import withMetadataArgument from './withMetadataArgument.js'
import { getCountries as _getCountries } from '../../core/index.js'

export function getCountries() {
	return withMetadataArgument(_getCountries, arguments)
}