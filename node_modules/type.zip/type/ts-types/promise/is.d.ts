declare function isPromise(value: any): boolean;
export default isPromise;
