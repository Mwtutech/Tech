// Deprecated. Import from 'metadata.js' directly instead.
export { getCountryCallingCode as default } from './metadata.js'