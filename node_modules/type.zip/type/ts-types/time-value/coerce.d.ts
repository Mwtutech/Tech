declare function coerceToTimeValue(value: any): number | null;
export default coerceToTimeValue;
