declare function isError(value: any): boolean;
export default isError;
