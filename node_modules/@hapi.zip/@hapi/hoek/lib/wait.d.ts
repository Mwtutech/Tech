import { wait } from "./index";

export = wait;
