import Metadata from './metadata.js';
export default function getCountries(metadata) {
  return new Metadata(metadata).getCountries();
}
//# sourceMappingURL=getCountries.js.map