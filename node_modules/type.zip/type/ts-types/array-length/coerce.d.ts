declare function coerceToArrayLength(value: any): number | null;
export default coerceToArrayLength;
