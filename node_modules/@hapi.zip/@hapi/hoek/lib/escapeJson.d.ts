import { escapeJson } from "./index";

export = escapeJson;
