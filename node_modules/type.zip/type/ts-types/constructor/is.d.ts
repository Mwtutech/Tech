declare function isConstructor(value: any): boolean;
export default isConstructor;
