module.exports = {
  completelyUnrelatedProperty: 'Just a very incorrect transport worker implementation'
}
