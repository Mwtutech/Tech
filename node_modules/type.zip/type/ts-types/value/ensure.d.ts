import { EnsureOptions } from '../ensure';

declare function ensureValue<T>(value: any, options?: EnsureOptions): T;
export default ensureValue;
