# `Math.round10` _(ext/math/round-10)_

Decimal round

```javascript
const round10 = require("ext/math/round-10");

round10(55.549, -1); // 55.5
round10(1.005, -2); // 1.01
```
