declare function isMap(value: any): boolean;
export default isMap;
