declare const _default: Uint16Array;
export default _default;
//# sourceMappingURL=decode-data-xml.d.ts.map