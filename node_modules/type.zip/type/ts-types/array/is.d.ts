declare function isArray(value: any): boolean;
export default isArray;
