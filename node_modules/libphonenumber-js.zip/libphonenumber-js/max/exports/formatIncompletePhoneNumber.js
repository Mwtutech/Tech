import withMetadataArgument from './withMetadataArgument.js'
import { formatIncompletePhoneNumber as _formatIncompletePhoneNumber } from '../../core/index.js'

export function formatIncompletePhoneNumber() {
	return withMetadataArgument(_formatIncompletePhoneNumber, arguments)
}