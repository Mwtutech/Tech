declare function isThenable(value: any): boolean;
export default isThenable;
