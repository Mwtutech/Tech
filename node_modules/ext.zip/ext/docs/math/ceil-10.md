# `Math.ceil10` _(ext/math/ceil-10)_

Decimal ceil

```javascript
const ceil10 = require("ext/math/ceil-10");

ceil10(55.51, -1); // 55.6
ceil10(-59, 1); // -50;
```
