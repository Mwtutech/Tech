var set = require("./set.js");
var getPrototypeOf = require("./getPrototypeOf.js");
function _superPropertySet(t, e, o, r, p, f) {
  return set(getPrototypeOf(f ? t.prototype : t), e, o, r, p);
}
module.exports = _superPropertySet, module.exports.__esModule = true, module.exports["default"] = module.exports;