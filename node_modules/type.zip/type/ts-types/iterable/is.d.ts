declare function isIterable(value: any, options?: { allowString?: boolean, denyEmpty?: boolean }): boolean;
export default isIterable;
