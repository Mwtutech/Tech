import withMetadataArgument from './withMetadataArgument.js'
import { getExampleNumber as _getExampleNumber } from '../../core/index.js'

export function getExampleNumber() {
	return withMetadataArgument(_getExampleNumber, arguments)
}