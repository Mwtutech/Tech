import { intersect } from "./index";

export = intersect;
