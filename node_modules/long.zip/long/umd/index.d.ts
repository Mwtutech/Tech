import Long from "../index.js";
export = Long;
