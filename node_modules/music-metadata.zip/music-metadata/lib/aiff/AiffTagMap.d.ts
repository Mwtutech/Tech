import { CommonTagMapper } from '../common/GenericTagMapper';
export declare class AiffTagMapper extends CommonTagMapper {
    constructor();
}
