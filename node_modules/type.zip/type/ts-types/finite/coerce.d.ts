declare function coerceToFinite(value: any): number | null;
export default coerceToFinite;
