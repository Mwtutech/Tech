import withMetadataArgument from './withMetadataArgument.js'
import { parsePhoneNumberWithError as _parsePhoneNumberWithError } from '../../core/index.js'

export function parsePhoneNumberWithError() {
	return withMetadataArgument(_parsePhoneNumberWithError, arguments)
}
