declare function isSet(value: any): boolean;
export default isSet;
