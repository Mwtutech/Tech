import { reachTemplate } from "./index";

export = reachTemplate;
