'use strict'

const { PassThrough } = require('stream')

async function run (opts) {
  return new PassThrough({})
}

module.exports = run
