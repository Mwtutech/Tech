import { Examples } from './types.d.js';

declare const examples: Examples;
export default examples;