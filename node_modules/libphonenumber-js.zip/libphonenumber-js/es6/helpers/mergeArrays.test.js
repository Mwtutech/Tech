import mergeArrays from './mergeArrays.js';
describe('mergeArrays', function () {
  it('should merge arrays', function () {
    mergeArrays([1, 2], [2, 3]).should.deep.equal([1, 2, 3]);
  });
});
//# sourceMappingURL=mergeArrays.test.js.map