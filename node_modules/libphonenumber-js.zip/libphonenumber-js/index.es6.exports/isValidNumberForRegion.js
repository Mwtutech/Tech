import withMetadataArgument from '../min/exports/withMetadataArgument.js'

import _isValidNumberForRegion from '../es6/legacy/isValidNumberForRegion.js'

export function isValidNumberForRegion() {
	return withMetadataArgument(_isValidNumberForRegion, arguments)
}
