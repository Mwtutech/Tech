import { stringify } from "./index";

export = stringify;
