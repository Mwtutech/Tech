import parseDigits from './parseDigits.js'

describe('parseDigits', () => {
	it('should parse digits', () => {
		parseDigits('+٤٤٢٣٢٣٢٣٤').should.equal('442323234')
	})
})