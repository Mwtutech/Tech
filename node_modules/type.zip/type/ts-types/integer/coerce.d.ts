declare function coerceToInteger(value: any): number | null;
export default coerceToInteger;
