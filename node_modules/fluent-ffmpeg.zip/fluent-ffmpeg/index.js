module.exports = require('./lib/fluent-ffmpeg');
