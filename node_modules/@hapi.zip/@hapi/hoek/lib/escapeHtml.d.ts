import { escapeHtml } from "./index";

export = escapeHtml;
