"use strict";

module.exports = 2147483647;
