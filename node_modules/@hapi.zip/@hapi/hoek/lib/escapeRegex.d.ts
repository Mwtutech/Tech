import { escapeRegex } from "./index";

export = escapeRegex;
