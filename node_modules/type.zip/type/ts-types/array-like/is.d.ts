declare function isArrayLike(value: any, options?: {allowString?: boolean}): boolean;
export default isArrayLike;
