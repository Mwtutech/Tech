declare function isPrototype(value: any): boolean;
export default isPrototype;
