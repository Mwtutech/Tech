#!/usr/bin/env node
console.error(
  '`pino` cli has been removed. Use `pino-pretty` cli instead.\n' +
  '\nSee: https://github.com/pinojs/pino-pretty'
)
process.exit(1)
