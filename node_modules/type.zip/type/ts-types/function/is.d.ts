declare function isFunction(value: any): boolean;
export default isFunction;
