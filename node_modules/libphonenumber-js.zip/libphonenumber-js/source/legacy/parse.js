import _parseNumber from '../parse.js'
import normalizeArguments from '../normalizeArguments.js'

export default function parseNumber() {
	const { text, options, metadata } = normalizeArguments(arguments)
	return _parseNumber(text, options, metadata)
}