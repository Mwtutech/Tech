export { EndOfStreamError } from './EndOfFileStream';
export { StreamReader } from './StreamReader';
