var temporalUndefined = require("./temporalUndefined.js");
var tdz = require("./tdz.js");
function _temporalRef(r, e) {
  return r === temporalUndefined ? tdz(e) : r;
}
module.exports = _temporalRef, module.exports.__esModule = true, module.exports["default"] = module.exports;