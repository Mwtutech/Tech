import parse from './parse.js'

export default function parsePhoneNumberWithError(text, options, metadata) {
	return parse(text, { ...options, v2: true }, metadata)
}