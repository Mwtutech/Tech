declare function isDate(value: any): boolean;
export default isDate;
