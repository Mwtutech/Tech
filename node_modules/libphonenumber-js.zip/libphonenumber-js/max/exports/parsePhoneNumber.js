import withMetadataArgument from './withMetadataArgument.js'
import { default as _parsePhoneNumber } from '../../core/index.js'

export function parsePhoneNumber() {
	return withMetadataArgument(_parsePhoneNumber, arguments)
}