import parsePhoneNumberWithError_ from './parsePhoneNumberWithError_.js'
import normalizeArguments from './normalizeArguments.js'

export default function parsePhoneNumberWithError() {
	const { text, options, metadata } = normalizeArguments(arguments)
	return parsePhoneNumberWithError_(text, options, metadata)
}