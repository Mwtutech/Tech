import child_process from 'child_process'

export default function exec(command)
{
	return child_process.execSync(command).toString().trim()
}