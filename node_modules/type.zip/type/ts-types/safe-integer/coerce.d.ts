declare function coerceToSafeInteger(value: any): number | null;
export default coerceToSafeInteger;
