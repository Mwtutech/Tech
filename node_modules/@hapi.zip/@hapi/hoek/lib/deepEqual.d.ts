import { deepEqual } from "./index";

export = deepEqual;
