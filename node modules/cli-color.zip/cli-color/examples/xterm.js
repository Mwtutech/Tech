'use strict';

var clc = require('../');

var msg = clc.xterm(202).bgXterm(236);
console.log(msg('Orange text on dark gray background'));
