declare function coerceToNumber(value: any): number | null;
export default coerceToNumber;
