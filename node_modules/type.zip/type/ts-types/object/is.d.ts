declare function isObject(value: any): boolean;
export default isObject;
