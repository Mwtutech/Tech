declare function coerceToBigInt(value: any): bigint | null;
export default coerceToBigInt;
