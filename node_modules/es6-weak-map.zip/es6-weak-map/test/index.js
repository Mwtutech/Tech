"use strict";

module.exports = function (T, a) {
	var obj = {};

	a((new T([[obj, "foo"]])).get(obj), "foo");
};
