import withMetadataArgument from './withMetadataArgument.js'
import { isValidPhoneNumber as _isValidPhoneNumber } from '../../core/index.js'

export function isValidPhoneNumber() {
	return withMetadataArgument(_isValidPhoneNumber, arguments)
}