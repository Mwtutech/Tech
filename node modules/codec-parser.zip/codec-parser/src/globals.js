export const headerStore = new WeakMap();
export const frameStore = new WeakMap();
