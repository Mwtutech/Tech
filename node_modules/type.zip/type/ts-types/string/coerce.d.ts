declare function coerceToString(value: any): string | null;
export default coerceToString;
